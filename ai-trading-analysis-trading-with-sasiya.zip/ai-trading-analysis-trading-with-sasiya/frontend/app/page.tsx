"use client";
import {useEffect,useMemo,useRef,useState} from "react";
import {createChart,ColorType,UTCTimestamp} from "lightweight-charts";
const API=process.env.NEXT_PUBLIC_API_BASE_URL||"http://localhost:8000";
type Market={symbol:string;baseAsset:string;price:string;change24h:string;volume24h:string;marketCap:number|null;cmcRank:number|null};
const money=(v:any)=>v==null?"Unavailable":Number(v).toLocaleString(undefined,{maximumFractionDigits:Number(v)<1?7:3});
function Chart({symbol,interval}:{symbol:string;interval:string}){const el=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(!el.current)return;const chart=createChart(el.current,{width:el.current.clientWidth,height:360,layout:{background:{type:ColorType.Solid,color:"#111b2e"},textColor:"#9dafca"},grid:{vertLines:{color:"#1d2a41"},horzLines:{color:"#1d2a41"}},timeScale:{timeVisible:true},rightPriceScale:{borderColor:"#293b59"}});
 const series=chart.addCandlestickSeries({upColor:"#38d9a5",downColor:"#ff7185",borderVisible:false,wickUpColor:"#38d9a5",wickDownColor:"#ff7185"});let alive=true;
 fetch(`${API}/api/klines/${symbol}?interval=${interval}&limit=500`).then(r=>r.json()).then(j=>{if(alive&&j.candles){series.setData(j.candles.map((x:any)=>({time:Math.floor(x[0]/1000) as UTCTimestamp,open:+x[1],high:+x[2],low:+x[3],close:+x[4]})));chart.timeScale().fitContent()}});
 const ws=new WebSocket(`wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@kline_${interval}`);
 ws.onmessage=e=>{const k=JSON.parse(e.data).k;if(alive)series.update({time:Math.floor(k.t/1000) as UTCTimestamp,open:+k.o,high:+k.h,low:+k.l,close:+k.c})};
 const ro=new ResizeObserver(()=>chart.applyOptions({width:el.current?.clientWidth||600}));ro.observe(el.current);
 return()=>{alive=false;ws.close();ro.disconnect();chart.remove()}},[symbol,interval]);return <div ref={el} style={{height:360,width:"100%"}}/>}
export default function Home(){
 const [markets,setMarkets]=useState<Market[]>([]),[search,setSearch]=useState(""),[symbol,setSymbol]=useState("BTCUSDT"),[interval,setInterval]=useState("1h"),[market,setMarket]=useState<any>(null),[analysis,setAnalysis]=useState<any>(null),[position,setPosition]=useState<any>(null),[loading,setLoading]=useState(false),[error,setError]=useState(""),[rankSource,setRankSource]=useState("loading");
 async function loadMarkets(){try{let r=await fetch(`${API}/api/markets?limit=2000`);if(!r.ok)throw Error("Market list unavailable");let j=await r.json();setMarkets(j.data);setRankSource(j.marketCapSource)}catch(e:any){setError(e.message)}}
 async function loadSelected(){try{let [m,p]=await Promise.all([fetch(`${API}/api/market/${symbol}`).then(r=>r.json()),fetch(`${API}/api/positioning/${symbol}`).then(r=>r.json())]);setMarket(m);setPosition(p)}catch(e:any){setError(e.message)}}
 async function analyze(){setLoading(true);setError("");try{let r=await fetch(`${API}/api/analyze/${symbol}?interval=${interval}`);let j=await r.json();if(!r.ok)throw Error(j.detail||"Analysis unavailable");setAnalysis(j)}catch(e:any){setError(e.message)}finally{setLoading(false)}}
 useEffect(()=>{loadMarkets()},[]);useEffect(()=>{loadSelected();setAnalysis(null)},[symbol]);useEffect(()=>{const id=setInterval(loadSelected,10000);return()=>clearInterval(id)},[symbol]);
 const filtered=useMemo(()=>markets.filter(m=>m.symbol.includes(search.toUpperCase())||m.baseAsset.toUpperCase().includes(search.toUpperCase())),[markets,search]);
 const sig=analysis?.signal,sigClass=sig==="BUY"?"green":sig==="SELL"?"red":"amber";
 return <main style={{maxWidth:1500,margin:"0 auto",padding:18}}>
 <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap",marginBottom:18}}>
 <div><div style={{fontSize:25,fontWeight:900}}>AI Trading Analysis</div><div className="muted">Trading With Sasiya · Live market research terminal</div></div>
 <div style={{fontSize:11,border:"1px solid #70592d",padding:"8px 12px",borderRadius:20,color:"#f4c76b"}}>EDUCATIONAL · PAPER-TRADING ONLY</div></header>
 {error&&<div className="panel red" style={{marginBottom:12}}>{error}</div>}
 <div style={{display:"grid",gridTemplateColumns:"minmax(270px,330px) 1fr",gap:14}}>
 <aside className="panel" style={{maxHeight:800,overflow:"hidden",display:"flex",flexDirection:"column"}}>
 <h3 style={{marginTop:0}}>Binance USDT Markets <span className="muted" style={{fontSize:11}}>({markets.length})</span></h3>
 <input placeholder="Search coin / symbol…" value={search} onChange={e=>setSearch(e.target.value)} style={{width:"100%",marginBottom:8}}/>
 <div className="muted" style={{fontSize:10,marginBottom:8}}>CMC ranking: {rankSource}. {rankSource!=="available"?"Configure backend CMC_API_KEY to enable rankings.":""}</div>
 <div style={{overflow:"auto"}}><table><thead><tr><th>Coin</th><th>Price</th><th>24H %</th><th>24H Vol</th><th>Market Cap</th></tr></thead><tbody>
 {filtered.map(m=><tr key={m.symbol} onClick={()=>setSymbol(m.symbol)} style={{background:symbol===m.symbol?"#1b2d49":undefined}}><td><b>{m.baseAsset}</b><div className="muted">{m.symbol} {m.cmcRank?`· #${m.cmcRank}`:""}</div></td><td>{money(m.price)}</td><td className={Number(m.change24h)>=0?"green":"red"}>{Number(m.change24h).toFixed(2)}%</td><td>{money(m.volume24h)}</td><td>{m.marketCap==null?"Unavailable":money(m.marketCap)}</td></tr>)}
 </tbody></table></div></aside>
 <section style={{display:"grid",gap:13,alignContent:"start"}}>
 <div className="panel"><div style={{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap",alignItems:"center"}}>
 <div><div className="muted" style={{fontSize:11}}>SELECTED MARKET</div><h2 style={{margin:"5px 0"}}>{symbol} <span className="muted" style={{fontSize:13}}>Binance Spot</span></h2>
 <div style={{fontSize:25,fontWeight:800}}>{market?money(market.lastPrice):"Loading…"} <span className={Number(market?.priceChangePercent)>=0?"green":"red"} style={{fontSize:14}}>{market?`${Number(market.priceChangePercent).toFixed(2)}%`:""}</span></div></div>
 <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}><select value={interval} onChange={e=>{setInterval(e.target.value);setAnalysis(null)}}>{["15m","1h","4h","1d","1w"].map(x=><option key={x}>{x}</option>)}</select><button onClick={analyze} disabled={loading}>{loading?"ANALYZING…":"ANALYZE COIN"}</button></div></div>
 <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginTop:14,fontSize:12}}>{[["24H HIGH",market?.highPrice],["24H LOW",market?.lowPrice],["24H QUOTE VOL",market?.quoteVolume],["24H CHANGE",market?.priceChangePercent==null?null:`${Number(market.priceChangePercent).toFixed(2)}%`]].map(([k,v])=><div key={k as string}><div className="muted">{k}</div><b>{v==null?"—":typeof v==="string"&&v.endsWith("%")?v:money(v)}</b></div>)}</div></div>
 <div className="panel"><h3 style={{marginTop:0}}>Live Candlestick Chart · {interval}</h3><Chart symbol={symbol} interval={interval}/></div>
 <div className="panel"><h3 style={{marginTop:0}}>Automated Analysis Results</h3>{!analysis?<div className="muted">Choose a market and click ANALYZE COIN. Real Binance historical candles are used.</div>:<>
 <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:9}}>{[["COIN",analysis.symbol],["MARKET DIRECTION",analysis.marketDirection],["TRADING SIGNAL",analysis.signal]].map(([k,v])=><div key={k} style={{background:"#17243b",padding:12,borderRadius:10}}><div className="muted" style={{fontSize:10}}>{k}</div><b className={k==="TRADING SIGNAL"?sigClass:""} style={{fontSize:17}}>{v}</b></div>)}</div>
 <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:9,marginTop:10}}>{[["ENTRY",analysis.entry],["STOP LOSS",analysis.stopLoss],["TAKE PROFIT 1",analysis.takeProfit1],["TAKE PROFIT 2",analysis.takeProfit2],["TAKE PROFIT 3",analysis.takeProfit3]].map(([k,v])=><div key={k} style={{background:"#17243b",padding:11,borderRadius:9}}><div className="muted" style={{fontSize:10}}>{k}</div><b>{money(v)}</b></div>)}</div>
 <div className="muted" style={{fontSize:11,marginTop:10}}>Evidence count: bullish {analysis.evidenceScore.bullish}/6 · bearish {analysis.evidenceScore.bearish}/6 · not a win probability.</div>
 <details style={{marginTop:12}}><summary style={{cursor:"pointer"}}>Technical indicators & SMC details</summary><pre style={{whiteSpace:"pre-wrap",fontSize:11,color:"#b7c7df"}}>{JSON.stringify({indicators:analysis.indicators,smc:analysis.smc,data:analysis.data},null,2)}</pre></details></>}</div>
 <div className="panel"><h3 style={{marginTop:0}}>Live Long / Short Positioning · Binance USD-M Futures</h3>{!position?<div className="muted">Loading futures statistics…</div>:<><div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10,fontSize:12}}>{[["LONG %",position.longPercent==null?null:`${Number(position.longPercent).toFixed(2)}%`],["SHORT %",position.shortPercent==null?null:`${Number(position.shortPercent).toFixed(2)}%`],["LONG/SHORT",position.longShortRatio],["OPEN INTEREST",position.openInterest],["FUNDING RATE",position.fundingRate==null?null:`${(Number(position.fundingRate)*100).toFixed(4)}%`]].map(([k,v])=><div key={k as string}><div className="muted">{k}</div><b>{v==null?"Unavailable":typeof v==="number"?money(v):v}</b></div>)}</div><div className="muted" style={{fontSize:10,marginTop:9}}>{position.note}</div></>}</div>
 </section></div>
 <div className="panel" style={{marginTop:14,fontSize:11,lineHeight:1.6,color:"#e6d6ac",borderColor:"#65512d"}}><b>Data & safety:</b> Educational research and paper-trading only. No real orders or exchange credentials. BUY/SELL labels are rule-based study scenarios, not personal advice or guaranteed signals. SMC/OB/FVG are simplified OHLCV detections. CMC ranks require a server-side API key. Unavailable provider data is not fabricated.</div>
 </main>
}
